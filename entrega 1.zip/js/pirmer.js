console.log('thanks god');
var name ;
name = 'BAM';
name = 'estela';
console.log('el nombre es ' + name);
var Array = [1,2,true,'jose'];
console.log(Array [3]);

var user = {
    Nombre: 'bruno',
    nacionalidad: 'argentino',
    edad :30,
    
};
/*console.log(user.edad);
console.log(user['Nombre']);

var sumar = 2 + 2; 
console.log(sumar);
var primerValor = 3; 
var segundoValor = 5; 
console.log(primerValor + segundoValor);

 var subTotal = 5 ;
 subTotal++;    
 console.log(subTotal);*/ 

 var nombre = prompt('cual es tu nombre?');
 console.log('hola ' + nombre);

 var numero = prompt('ingrese su telefono ');
 var numero2 = 11;
 var numero3= parseInt(numero) + numero2;
 console.log(numero3);

 var numero = prompt('ingrese otro telefono ');
 var numero2 = 11;
 var numero3= parseInt(numero) - numero2;
 console.log(numero3);

 var numero = prompt('otro mas ');
 var nuevoNumero = prompt('otro mas y listo ');
 var suma = parseInt (numero) +  parseInt(nuevoNumero);
 console.log(suma);

